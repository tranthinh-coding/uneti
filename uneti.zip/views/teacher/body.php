<div class="wrapper">
  <div class="container">
    <form class="form" action="/?c=1&a=view" method="post">
      <div class="form-wrapp-group">
        <div class="form-group">
          <label class="form-label" for="department">Khoa</label>
          <select class="form-control" name="department" id="department">
            <option value=""></option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" for="class">Lớp học phần</label>
          <select class="form-control" name="class" id="class">
            <option value=""></option>
          </select>
        </div>
      </div>

      <div class="form-button">
        <button class="btn btn-green btn-full" class="form-submit" name="submit">Tìm</button>
      </div>
    </form>
  </div>

  <?php if($action == 'view'): ?>
      <?php require_once "views/teacher/tableStudentScore.php"; ?>
  <?php endif; ?>
</div>

<?php if (!strpos($res, 'error')): ?>
<script>
  const department = document.getElementById("department");
  const className = document.getElementById("class");

  function changeOptionClassName(arr) {
    let classOption = '<option></option>';
    arr.forEach(e => {
      classOption += `<option value="${e['ma_lop_hoc_phan']}">${e['ten_lop_hoc_phan']}</option>`;
    })
    className.innerHTML = classOption;
  }

  function generalOption(element, object, keyOfValue) {
    const id = Object.keys(object);
    let strOption = '<option></option>';
    id.forEach(e => {
      strOption += `<option value="${object[e][0][keyOfValue]}">${e}</option>`;
    })
    element.innerHTML = strOption;
  }

  let a = <?php echo($res); ?>;
  let objectGroupByDepartment = a.reduce((obj, currData) => {
    if (!obj[currData['ma_khoa']] && obj[currData['ma_khoa']] != 0) {
      obj[currData['ma_khoa']] = [];
    } 
    obj[currData['ma_khoa']].push(currData);
    return obj;
  }, {})

  console.log(objectGroupByDepartment);

  const departmentId = Object.keys(objectGroupByDepartment);
  let departMentOption = '<option></option>';
  departmentId.forEach(e => {
    departMentOption += `<option value="${e}">${objectGroupByDepartment[e][0]['ten_khoa']}</option>`;
  })
  department.innerHTML = departMentOption;

  department.addEventListener('change', (event) => changeOptionClassName(objectGroupByDepartment[event.target.value]))
  
</script>
<?php endif; ?>