<?php
require_once "views/flashMessage.php";
?>
<div class="flex">
  <?php 
    require_once "views/teacher/navbar.php";
    require_once "views/teacher/body.php";
  ?>
</div>
