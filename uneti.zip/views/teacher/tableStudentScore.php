<style>
  .boxed {
    margin-top: 40px;
    max-height: calc(100vh - 280px);
    overflow: hidden;
  }
</style>
<?php if (!!$listStudent) : ?>

  <div class="container">
    <form action="/?c=1&a=save-score" method="post">
      <div class="boxed">
        <h3 class="table-header">Nhập điểm sinh viên</h3>
        <button type="submit" name="submit" class="btn btn-red">Lưu điểm</button>
        <style> 
          .table-wrapper {
            max-height: calc(100vh - 300px);
            overflow: scroll;
            padding-bottom: 100px;
            width: 100%;
          }
        </style>
        <div class="table-wrapper">
          <table class="score-table">
            <tr class="score-table-heading">
              <th style="min-width: 120px !important;">Mã sinh viên</th>
              <th style="min-width: 120px !important;">Họ</th>
              <th style="min-width: 120px !important;">Tên</th>
              <th style="min-width: 120px !important;">Điểm hệ 1</th>
              <th style="min-width: 120px !important;">Điểm hệ 2</th>
              <th style="min-width: 120px !important;">Điểm chuyên cần</th>
              <th style="min-width: 100px !important;">TB thường kì</th>
              <th style="min-width: 100px !important;">Điểm thi</th>
              <th style="min-width: 100px !important;">Điểm tổng kết</th>
              <th style="min-width: 100px !important;">Thang điểm 4</th>
              <th style="min-width: 100px !important;">Xếp loại</th>
            </tr>

            <?php foreach ($listStudent as $each) : ?>
              <tr class="score-row">
                <td name="id-<?php echo $each['ma_sinh_vien'] ?>" style="min-width: 120px;" class="score-property score-name"><?php echo $each['ma_sinh_vien'] ?></td>
                <td style="min-width: 120px;" class="score-property"><?php echo $each['ho'] ?></td>
                <td style="min-width: 120px;" class="score-property"><?php echo $each['ten'] ?></td>
                <td style="min-width: 120px;" class="score-property">
                  <input name="hs1-<?php echo $each['ma_sinh_vien'] ?>" class="form-control" type="text" value="<?php echo $each['he_so_1'] ?>">
                </td>
                <td style="min-width: 120px;" class="score-property">
                  <input name="hs2<?php echo $each['ma_sinh_vien'] ?>" class="form-control" type="text" value="<?php echo $each['he_so_2'] ?>">
                </td>
                <td style="min-width: 120px;" class="score-property">
                  <input name="chuyen-can-<?php echo $each['ma_sinh_vien'] ?>" class="form-control" type="text" value="<?php echo $each['diem_chuyen_can'] ?>">
                </td>
                <td style="min-width: 100px;" class="score-property"><?php echo $each['diem_qua_trinh'] ?></td>
                <td style="min-width: 100px;" class="score-property">
                  <input name="thi-<?php echo $each['ma_sinh_vien'] ?>" class="form-control" type="text" value="<?php echo $each['diem_thi'] ?>">
                </td>
                <td style="min-width: 100px;" class="score-property"><?php echo $each['diem_tong_ket'] ?></td>
                <td style="min-width: 100px;" class="score-property"><?php echo $each['tong_ket_he_4'] ?></td>
                <td style="min-width: 100px;" class="score-property"><?php echo $each['xep_loai'] ?></td>
              </tr>
            <?php endforeach; ?>
          </table>
        </div>
      </div>
    </form>
  </div>
<?php endif; ?>