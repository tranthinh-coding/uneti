<div class="sv-navbar">
  <div class="container">
      <div class="nav-content">
          <div class="nav-left">
              <div class="avatar">
                  <img src="https://th.bing.com/th/id/R.317e43d870cdc72dd3a5e6a2c60e4836?rik=mQ8ZWofMHFwWug" alt="">
              </div>
              <div class="user-name">
                  <?php echo $userInfo->ho . " " . $userInfo->ten ?>
              </div>
          </div>
          <div class="nav-right">
              <a href="?c=sy&a=signout">
                  <button class="btn btn-red">
                      Thoát
                  </button>
              </a>
          </div>
      </div>
  </div>
</div>
