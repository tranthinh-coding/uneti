<?php

require_once "views/headTag.php";
require_once "router.php";
