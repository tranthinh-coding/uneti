<?php

jumpToSigninFormIfNotExistsUser();

$action = $_GET['a'] ?? '';

switch ($action) {
    case 'create-account': {
        require_once "models/admin/admin.php";
        $AdminModel  = new AdminModel();
        if (isset($_POST['submit'])) {
            $AdminModel->createUser();
        }
        $khoa        = $AdminModel->getList("khoa");
        $khoaHoc     = $AdminModel->getList("khoa_hoc");
        $lopBienChe  = (new Database())->table("lop_bien_che")->orderBy("ten_lop")->selectAll();
        require_once "views/admin/index.php";
        break;
    }
    case 'create-class': {
        require_once "models/admin/admin.php";
        $AdminModel  = new AdminModel();
        if (isset($_POST['submit'])) {
            $AdminModel->createClass();
        }
        $khoa        = $AdminModel->getList('khoa');
        $giangVien   = $AdminModel->getListTeachers();
        $monHocPhan  = $AdminModel->getList('mon_hoc_phan');
        $lopBienChe  = $AdminModel->getList("lop_bien_che");
        $khoaHoc     = $AdminModel->getList("khoa_hoc");
        require_once "views/admin/index.php";
        break;
    }
    case 'ud': {
        require_once "models/admin/admin.php";
        if (isset($_POST['submit'])) {
            (new AdminModel)->updateLopHocPhan();
        }
        $giangVien   = (new AdminModel)->getListTeachers();
        $lopHocPhan  = (new AdminModel)->getList("lop_hoc_phan");
        require_once "views/admin/index.php";
        break;
    }
    case 'view-te': {
        require_once "models/admin/admin.php";
        $teachers   = (new AdminModel())->getListTeachers();
        require_once "views/admin/index.php";
        break;
    }
    case 'view-st': {
        require_once "models/admin/admin.php";
        $teachers   = (new AdminModel())->getListStudents();
        require_once "views/admin/index.php";
        break;
    }
    case 'view-cl': {
        // require_once "models/admin/admin.php";
        // $teachers   = (new AdminModel())->getListTeachers();
        // require_once "views/admin/index.php";
        break;
    }
    // case 'search': {
    //     // if (isset($_POST['submit'])) {
    //     //     require_once "models/admin/admin.php";
    //     //     $user = (new AdminModel)->searchUser();
    //     // }
    //     // require_once "views/admin/index.php";
    //     break;
    // }
    case '': default: {
        require_once "models/admin/admin.php";
        $userInfo = (new AdminModel)->getAdmin($userSession->id);
        require_once "views/admin/index.php";
        break;
    }
}

