<?php

$action = $_GET['a'] ?? '';

jumpToSigninFormIfNotExistsUser();

require_once "models/teacher/teacher.php";
switch ($action) {
  case "save-score": {
    (new TeacherModel)->saveScoreStudent();
    break;
  }
  case 'view': {
    $listStudent = (new TeacherModel)->getListStudent($userSession->id);
  }
  case '': default: {
    $userInfo = (new TeacherModel)->getTeacherInfo($userSession->id);
    $listClass = (new TeacherModel)->getListClass($userSession->id);
    $res = (new TeacherModel)->getDepartment($userSession->id);
    require_once "views/teacher/index.php";
    break;
  }
}
