<?php

require_once "models/database.php";

class TeacherModel {
  /**
   * @return bool
   */
  private function checkSubmitAndServerPost(): bool {
    return $_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['submit']);
  }

  public function getTeacherInfo($tid) {
    return (new Database())
      ->table("giang_vien")
      ->selectId($tid);
  }

  public function getListClass($tid) {
    return (new Database())
      ->table('lop_hoc_phan')
      ->selectByField([
        'ma_giang_vien' => $tid
      ]);
  }

  public function getDepartment($tid) {
    $result = (new Database())
      ->selectCustom("SELECT 
                      lhp.ten_lop_hoc_phan, 
                      lhp.ma_khoa, lhp.id AS ma_lop_hoc_phan, 
                      khoa.ten_khoa, 
                      lop_bien_che.ten_lop AS ten_lop_bien_che
                    FROM 
                      (SELECT * FROM lop_hoc_phan WHERE ma_giang_vien = $tid) AS lhp
                    JOIN khoa
                    ON lhp.ma_khoa = khoa.id
                    JOIN lop_bien_che
                    ON lhp.ma_lop_bien_che = lop_bien_che.id");

    $res = [];
    while ($each = mysqli_fetch_assoc($result)) $res[] = $each;
    if ($res) {
      return json_encode($res, JSON_UNESCAPED_UNICODE);
    }
    return json_encode(["error" => 'null']);
  }

  public function saveScoreStudent() {
    if ($this->checkSubmitAndServerPost()) {

      // Lay diem trong form ve mot array sau do insert: id => typescore -> score
      $arr = [
        '1' => [
          'he_so_1' => 9,
          'he_so_2' => 8,
          'chuyen_can' => 0,
          'thi' => 0
        ],
        '2' => [

        ]
      ];


      
    }
  }

  public function getListStudent($tid) {
    if ($this->checkSubmitAndServerPost()) {
      $class = testInput($_POST['class']);

      $db = new Database();
      $resultQuery = $db->selectCustom("SELECT d.ma_sinh_vien,
                                        sv.ho, 
                                        sv.ten,
                                        d.he_so_1, 
                                        d.he_so_2, 
                                        d.diem_chuyen_can, 
                                        d.diem_qua_trinh,
                                        d.diem_thi, 
                                        d.xep_loai,
                                        d.diem_tong_ket,
                                        d.tong_ket_he_4
                                    FROM
                                      (SELECT * FROM diem_hoc_phan
                                        WHERE ma_lop_hoc_phan = $class) AS d
                                    JOIN sinh_vien AS sv
                                    ON d.ma_sinh_vien = sv.id
                                    ORDER BY sv.ten");
      $res = [];
      foreach($resultQuery as $each) {
        $res[] = $each;
      } 
      return $res;
    }
  }
}
