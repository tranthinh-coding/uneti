<?php
require_once "views/flashMessage.php";
require_once "views/student/navbar.php";
require_once "views/student/tableScore.php";
