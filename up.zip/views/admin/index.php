<?php
require_once "views/flashMessage.php";
?>

<div style="display: flex; width:100%">
    <?php
    require_once "views/admin/navbar.php";

    switch($action) {
    case 'create': {
        require_once "views/admin/insertForm.php";
        break;
    }
    case 'view': {
        require_once "views/admin/searchUser.php";
        break;
    }
    }
    ?>
</div>
