<?php
require_once "views/flashMessage.php";
?>
<div>
    <?php
    require_once "views/teacher/navbar.php";

    require_once "views/teacher/body.php";
    ?>
</div>
