<?php

$action = $_GET['a'] ?? '';

jumpToSigninFormIfNotExistsUser();

switch ($action) {
case '': default: {
  require_once "models/teacher/teacher.php";
  $userInfo = (new TeacherModel)->getTeacherInfo($userSession->id);
  require_once "views/teacher/index.php";
  break;
}
}
