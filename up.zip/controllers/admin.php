<?php

jumpToSigninFormIfNotExistsUser();

$action = $_GET['a'] ?? '';

switch ($action) {
case "ins": {
    require_once "models/database.php";
    require_once "models/inc/signup.inc.php";
    break;
}
case 'create': {
    require_once "models/admin/admin.php";
    if (isset($_POST['submit'])) {
        (new AdminModel)->createUser();
    }
    $db          = new Database();
    $khoa        = $db->table("khoa")->selectAll();
    $lopBienChe  = $db->table("lop_bien_che")->selectAll();
    $khoaHoc     = $db->table("khoa_hoc")->selectAll();
    require_once "views/admin/index.php";
    break;
}
case 'view': {
    if (isset($_POST['submit'])) {
        require_once "models/admin/admin.php";
        $user = (new AdminModel)->searchUser();
    }
    require_once "views/admin/index.php";
    break;
}
case '': default: {
    require_once "models/admin/admin.php";
    $userInfo = (new AdminModel)->getAdmin($userSession->id);
    require_once "views/admin/index.php";
    break;
}
}

