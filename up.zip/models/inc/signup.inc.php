<?php 

$existUser = UseUser();

if (! $existUser) {
  redirect("/?c=sy");
}

if ($existUser->extra != 0) {
  redirect("/");
}

function checkDataValid(...$data) {
  foreach($data as $val)
  if (!$val && $val != 0)
    redirect("/?c=0&a=create"); 
}

if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['submit'])) {
  $type           = testInput($_POST["ty"]);    
  
  $firstname      = testInput($_POST['firstname']);
  $lastname       = testInput($_POST['lastname']);
  $birthday       = testInput($_POST['birthday']);
  $gender         = testInput($_POST['gender']);
  $department     = testInput($_POST['department']);

  if ($type == "st") {
    $course         = testInput($_POST['course']);
    $payroll        = testInput($_POST['payroll']);
    
    checkDataValid($type, $firstname, $lastname, $birthday, $gender, $course, $payroll, $department);
    
    (new Database())
      ->table("sinh_vien")
      ->create([
        'ten' => "'$lastname'",
        'ho' => "'$firstname'",
        'ngay_sinh' => "'$birthday'",
        'gioi_tinh' => "$gender",
        'ma_khoa_hoc' => "$course",
        'ma_khoa' => "$department",
        'ma_lop_bien_che' => "$payroll"
      ]);
  }
  else if ($type == "te") {
    checkDataValid($type, $firstname, $lastname, $birthday, $gender, $department);
    (new Database())
      ->table("giang_vien")
      ->create([
        'ten' => "'$lastname'",
        'ho' => "'$firstname'",
        'ngay_sinh' => "'$birthday'",
        'gioi_tinh' => "$gender",
        'ma_khoa' => "$department"
      ]);
  }
  redirect("/?c=0&a=create"); 
}

redirect("/");
