<?php

require_once "models/database.php";

class TeacherModel {
  public function getTeacherInfo($tid) {
    return (new Database())
      ->table("giang_vien")
      ->selectId($tid);
  }
}
