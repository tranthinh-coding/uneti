<?php

require_once "models/database.php";

class AdminModel {
    public function getAdmin($adId) {
        return (new Database())
            ->table('admin')
            ->selectId($adId);
    }

    public function createUser() {
        $type = $_GET['ty'] ?? '';
        $db = new Database();
        if ($type === 'st') {
            $db->table("sinh_vien");
        } else if ($type === 'te') {
            $db->table("giang_vien");
        }
        
    }

    public function searchUser() {
        $type = $_GET['ty'] ?? '';
        $db = new Database();
        if ($type === 'st') {
            $db->table("sinh_vien");
        } else if ($type === 'te') {
            $db->table("giang_vien");
        }

        $uid = $_POST['id'] ?? null;
        if ($uid) {
            return mysqli_fetch_object($db->selectId($uid));
        } 
        return false;
    }
}
