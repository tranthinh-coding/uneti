<?php

class Database {
  private $_conn;

  private string $_hostname  = "localhost";
  private string $_username  = "root";
  private string $_password  = "";
  // private string $_username  = "qrgiamgia_think";
  // private string $_password  = "021220010911200210102002@";
  private string $_dbname    = "uneti";

  private string $_table;
  private int $_offset       = 0;
  private int $_limit        = -1;
  private string $_orderBy   = "";
  private string $_typeOrder = "ASC";

  private function runSql($sql) {
    return mysqli_query($this->_conn, $sql);
  }

  public function __construct() {
    $this->_conn    = mysqli_connect($this->_hostname, $this->_username, $this->_password, $this->_dbname);
    mysqli_set_charset($this->_conn, "utf8");
  }

  public function table($tableName) {
    $this->_table = $tableName;
    return $this;
  }

  public function offset($offset) {
    $this->_offset = $offset;
    return $this;
  }

  public function limit($limit) {
    $this->_limit = $limit;
    return $this;
  }

  public function update($id, $arr) : void {
    $keyValues    = [];
    foreach($arr as $column => $value) {
      $value = testInput($value);
      $keyValues[] = "$column = '$value'";
    }
    $keyAndValues = implode(",", array_keys($keyValues));
    
    $id = testInput($id);
    $sql = "UPDATE $this->_table SET " . $keyAndValues .  " WHERE id = '$id'";
    $this->runSql($sql);
  } 

  public function deleteId($id) {
    $id = testInput($id);
    $sql = "DELETE FROM $this->table WHERE id = '$id'";
    $this->runSql($sql);
  }

  public function create($arr) {
    $fields     = implode(",", array_keys($arr));
    $values     = array_values($arr);
    $bindValues = implode(",", array_map(function ($e) {return testInput($e);}, $values));
    $sql        = "INSERT INTO $this->_table ($fields) VALUES ($bindValues);";

    $this->runSql($sql);
    return mysqli_insert_id($this->_conn);
  }

  public function selectAll() : array {
    $sql    = "SELECT * FROM $this->_table ";
    if ($this->_limit >= 0)   $sql .= " LIMIT $this->_offset, $this->_limit";
    if ($this->_orderBy)     $sql .= " ORDER BY $this->_orderBy $this->_typeOrder";
    $result = $this->runSql($sql);
    $res    = [];
    foreach($result as $each) {
      $res[] = $each;
    }
    return $res;
  }

  public function selectField($arr, $field = ['*']) {
    $whereCondition = [];
    foreach($arr as $column => $value) {
      $val = testInput($value);
      $whereCondition[] = "$column = '$val'";
    }
    $fields         = implode(",", $field);
    $whereCondition = implode(" AND ", $whereCondition);
    $sql            = "SELECT $fields FROM $this->_table WHERE $whereCondition ";
    if ($this->_limit >= 0)   $sql .= " LIMIT $this->_offset, $this->_limit";
    if ($this->_orderBy)     $sql .= " ORDER BY $this->_orderBy $this->_typeOrder";
    $result = $this->runSql($sql);
    $res    = [];
    foreach($result as $each) {
      $res[] = $each;
    }
    return $res;
  }

  public function selectCustom($sql) {
    return $this->runSql($sql);
  }

  public function selectId($id) {
    $id = testInput($id);
    $sql    = "SELECT * FROM $this->_table WHERE id = '$id'";
    $result = $this->runSql($sql);
    return mysqli_fetch_object($result);
  }
}
